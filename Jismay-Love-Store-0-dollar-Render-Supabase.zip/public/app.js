const PRODUCTS=[
{id:1,name:"Sandales marron brillantes",cat:"Femme",price:1750,img:"images/produit-1.jpg",stock:24},
{id:2,name:"Sandales noires à motifs",cat:"Homme",price:1750,img:"images/produit-2.jpg",stock:24},
{id:3,name:"Sandales noires classiques",cat:"Femme",price:1750,img:"images/produit-3.jpg",stock:24},
{id:4,name:"Sandales noires croisées",cat:"Homme",price:1750,img:"images/produit-4.jpg",stock:24},
{id:5,name:"Sandales marron élégantes",cat:"Femme",price:1750,img:"images/produit-5.jpg",stock:24},
{id:6,name:"Sandales marron",cat:"Homme",price:1750,img:"images/produit-6.jpg",stock:24},
{id:7,name:"Sandales marron design",cat:"Femme",price:1750,img:"images/produit-7.jpg",stock:24},
{id:8,name:"Sandales noires",cat:"Homme",price:1750,img:"images/produit-8.jpg",stock:24},
{id:11,name:"Sandales enfant — Fille",cat:"Enfant",price:500,img:"images/produit-2.jpg",stock:24},
{id:12,name:"Sandales enfant — Garçon",cat:"Enfant",price:500,img:"images/produit-3.jpg",stock:24},
{id:9,name:"Téléphone bleu",cat:"Téléphones",price:15000,img:"images/produit-9.jpg",stock:24},
{id:10,name:"Téléphone blanc",cat:"Téléphones",price:15000,img:"images/produit-10.jpg",stock:24}
];
let cart=[];
const money=n=>new Intl.NumberFormat("fr-FR").format(n)+" HTG";
function render(){
 const q=(document.getElementById("search").value||"").toLowerCase();
 const c=document.getElementById("category").value;
 const list=PRODUCTS.filter(p=>(c==="Toutes"||p.cat===c)&&p.name.toLowerCase().includes(q));
 document.getElementById("products").innerHTML=list.map(p=>`
 <article class="card"><div class="photo"><img src="${p.img}" alt="${p.name}" loading="lazy"></div>
 <div class="body"><span class="badge">${p.cat}</span><h3>${p.name}</h3><div class="price">${money(p.price)}</div>
 <div class="stock">📦 ${p.stock} disponibles</div>
 <button class="btn primary" ${p.stock<1?"disabled":""} onclick="add(${p.id})">${p.stock?"Ajouter au panier":"Épuisé"}</button></div></article>`).join("")||"<p>Aucun produit trouvé.</p>";
}
function add(id){const p=PRODUCTS.find(x=>x.id===id);if(!p||p.stock<1)return;p.stock--;const x=cart.find(x=>x.id===id);x?x.qty++:cart.push({id:p.id,name:p.name,cat:p.cat,price:p.price,qty:1});update();render();openCart()}
function change(id,d){const x=cart.find(x=>x.id===id),p=PRODUCTS.find(x=>x.id===id);if(!x||!p)return;if(d>0){if(!p.stock)return;p.stock--;x.qty++}else{if(x.qty===1){remove(id);return}x.qty--;p.stock++}update();render()}
function remove(id){const i=cart.findIndex(x=>x.id===id);if(i<0)return;const x=cart[i],p=PRODUCTS.find(x=>x.id===id);if(p)p.stock+=x.qty;cart.splice(i,1);update();render()}
function update(){document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-row"><div class="cart-row-top"><b>${x.name}</b><strong>${money(x.price*x.qty)}</strong></div><div class="qty"><button onclick="change(${x.id},-1)">−</button><b>${x.qty}</b><button onclick="change(${x.id},1)">+</button><button class="remove" onclick="remove(${x.id})">Retirer</button></div></div>`).join(""):"<p>Votre panier est vide.</p>";document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0))}
function openCart(){document.getElementById("cartModal").classList.remove("hidden");update()}
function closeCart(){document.getElementById("cartModal").classList.add("hidden")}
function checkout(){if(!cart.length){alert("Votre panier est vide.");return}const lines=cart.map(x=>`- ${x.name} x${x.qty}: ${money(x.price*x.qty)}`).join("\n");const total=money(cart.reduce((s,x)=>s+x.price*x.qty,0));const msg=`Bonjour Jismay-Love Store !\n\nJe souhaite commander :\n${lines}\n\nTotal : ${total}\n\nNom :\nTéléphone :\nAdresse de livraison :`;window.open("https://wa.me/50942585884?text="+encodeURIComponent(msg),"_blank")}
render();update();