# Jismay-Love Store — Production deployment

## Configuration
- Administrateur: Mario Jean-Pierre
- Login: mario
- Téléphone admin: 40970981
- Paiement: NatCash
- Numéro NatCash: +50942585884
- Devise: HTG
- Adresse: #102, Sicar, Fort-Liberté, Nord-Est, Haïti

## Déploiement
1. Installer Node.js 20+.
2. Copier `.env.example` vers `.env` sur le serveur.
3. Générer un secret JWT long et aléatoire.
4. Créer un mot de passe administrateur unique d'au moins 12 caractères.
5. Générer son hash: `node server/create-admin-hash.js "VOTRE_MOT_DE_PASSE"`
6. Mettre le hash dans `ADMIN_PASSWORD_HASH`.
7. `npm install`
8. `node server/seed.js` (une seule fois sur une base neuve).
9. `npm start`
10. Mettre HTTPS devant Node (reverse proxy Nginx/Caddy ou plateforme cloud).
11. Sauvegarder `data/store.db` régulièrement.

## Important
Ne pas mettre `.env` dans Git. Pour une vraie mise en production, utilisez HTTPS, sauvegardes, monitoring et idéalement 2FA pour l'administration.

## API
- `POST /api/admin/login`
- `GET /api/products`
- `POST /api/orders`
- `GET /api/admin/orders` (admin)
- `GET /api/admin/products` (admin)
- `POST /api/admin/products` (admin)
- `PATCH /api/admin/products/:id` (admin)
- `PATCH /api/admin/orders/:id` (admin)
