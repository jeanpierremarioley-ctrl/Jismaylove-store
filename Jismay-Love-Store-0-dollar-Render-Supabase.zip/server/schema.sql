
CREATE TABLE IF NOT EXISTS products (
 id BIGSERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 price_htg INTEGER NOT NULL CHECK(price_htg >= 0),
 stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
 image TEXT,
 active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS orders (
 id BIGSERIAL PRIMARY KEY,
 customer_name TEXT NOT NULL,
 customer_phone TEXT NOT NULL,
 delivery_address TEXT NOT NULL,
 total_htg INTEGER NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'NatCash',
 payment_reference TEXT,
 payment_status TEXT NOT NULL DEFAULT 'pending',
 order_status TEXT NOT NULL DEFAULT 'new',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS order_items (
 id BIGSERIAL PRIMARY KEY,
 order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 product_id BIGINT NOT NULL REFERENCES products(id),
 product_name TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 unit_price_htg INTEGER NOT NULL
);
