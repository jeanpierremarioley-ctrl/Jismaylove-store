const bcrypt=require("bcryptjs"); const p=process.argv[2]; if(!p||p.length<12){console.error("12+ chars");process.exit(1)} console.log(bcrypt.hashSync(p,12));
