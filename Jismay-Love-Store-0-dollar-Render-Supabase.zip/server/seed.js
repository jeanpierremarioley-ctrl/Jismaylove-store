
const {Pool}=require("pg");
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});
const products=[
["Sandales marron brillantes","Femme",1750,24,"images/produit-1.jpg"],
["Sandales noires à motifs","Homme",1750,24,"images/produit-2.jpg"],
["Sandales noires classiques","Femme",1750,24,"images/produit-3.jpg"],
["Sandales noires croisées","Homme",1750,24,"images/produit-4.jpg"],
["Sandales marron élégantes","Femme",1750,24,"images/produit-5.jpg"],
["Sandales marron","Homme",1750,24,"images/produit-6.jpg"],
["Sandales marron design","Femme",1750,24,"images/produit-7.jpg"],
["Sandales noires","Homme",1750,24,"images/produit-8.jpg"],
["Sandales enfant — Fille","Enfant",500,24,"images/produit-2.jpg"],
["Sandales enfant — Garçon","Enfant",500,24,"images/produit-3.jpg"],
["Téléphone bleu","Téléphones",15000,24,"images/produit-9.jpg"],
["Téléphone blanc","Téléphones",15000,24,"images/produit-10.jpg"]];
(async()=>{for(const p of products) await pool.query(
"INSERT INTO products(name,category,price_htg,stock,image) SELECT $1,$2,$3,$4,$5 WHERE NOT EXISTS(SELECT 1 FROM products WHERE name=$1)",
p); await pool.end(); console.log("Seed complete")})().catch(e=>{console.error(e);process.exit(1)});
