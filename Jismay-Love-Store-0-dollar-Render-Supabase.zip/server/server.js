
const express=require("express");
const helmet=require("helmet");
const rateLimit=require("express-rate-limit");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const {Pool}=require("pg");
const path=require("path");
const fs=require("fs");

const app=express();
const PORT=Number(process.env.PORT||3000);
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});
const JWT_SECRET=process.env.JWT_SECRET||"";
const ADMIN_LOGIN=process.env.ADMIN_LOGIN||"mario";
const ADMIN_HASH=process.env.ADMIN_PASSWORD_HASH||"";

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"200kb"}));
app.use(rateLimit({windowMs:15*60*1000,limit:200}));
app.use(express.static(path.join(__dirname,"..","public")));

async function init(){
  if(!process.env.DATABASE_URL) throw new Error("DATABASE_URL manke");
  await pool.query(fs.readFileSync(path.join(__dirname,"schema.sql"),"utf8"));
}

function auth(req,res,next){
  try{
    const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
    if(!token||!JWT_SECRET) return res.status(401).json({error:"Authentification requise"});
    req.admin=jwt.verify(token,JWT_SECRET); next();
  }catch{return res.status(401).json({error:"Session invalide ou expirée"});}
}

app.post("/api/admin/login",async(req,res)=>{
  const {login,password}=req.body||{};
  if(!ADMIN_HASH||!JWT_SECRET) return res.status(503).json({error:"Administration non configurée"});
  if(login!==ADMIN_LOGIN||!(await bcrypt.compare(String(password||""),ADMIN_HASH)))
    return res.status(401).json({error:"Identifiant ou mot de passe incorrect"});
  const token=jwt.sign({login:ADMIN_LOGIN,name:"Mario Jean-Pierre",role:"admin"},JWT_SECRET,{expiresIn:"8h"});
  res.json({token,admin:{name:"Mario Jean-Pierre",login:ADMIN_LOGIN,role:"admin"}});
});

app.get("/api/products",async(req,res)=>{
  const {rows}=await pool.query("SELECT * FROM products WHERE active=TRUE ORDER BY id");
  res.json(rows);
});

app.post("/api/orders",async(req,res)=>{
  const {customer_name,customer_phone,delivery_address,items,payment_reference}=req.body||{};
  if(!customer_name||!customer_phone||!delivery_address||!Array.isArray(items)||!items.length)
    return res.status(400).json({error:"Informations de commande incomplètes"});
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    let total=0, checked=[];
    for(const it of items){
      const q=Number(it.quantity);
      const r=await client.query("SELECT * FROM products WHERE id=$1 AND active=TRUE FOR UPDATE",[it.product_id]);
      const p=r.rows[0];
      if(!p||!Number.isInteger(q)||q<1||q>p.stock) throw new Error("Stock insuffisant pour un produit");
      total+=p.price_htg*q; checked.push({p,q});
    }
    const o=await client.query(`INSERT INTO orders
      (customer_name,customer_phone,delivery_address,total_htg,payment_method,payment_reference)
      VALUES($1,$2,$3,$4,'NatCash',$5) RETURNING id`,
      [customer_name,customer_phone,delivery_address,total,payment_reference||null]);
    for(const {p,q} of checked){
      await client.query(`INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price_htg)
        VALUES($1,$2,$3,$4,$5)`,[o.rows[0].id,p.id,p.name,q,p.price_htg]);
      await client.query("UPDATE products SET stock=stock-$1 WHERE id=$2",[q,p.id]);
    }
    await client.query("COMMIT");
    res.status(201).json({id:o.rows[0].id,total});
  }catch(e){await client.query("ROLLBACK");res.status(400).json({error:e.message});}
  finally{client.release();}
});

app.get("/api/admin/orders",auth,async(req,res)=>{
  const {rows}=await pool.query("SELECT * FROM orders ORDER BY id DESC"); res.json(rows);
});
app.get("/api/admin/products",auth,async(req,res)=>{
  const {rows}=await pool.query("SELECT * FROM products ORDER BY id"); res.json(rows);
});
app.post("/api/admin/products",auth,async(req,res)=>{
  const {name,category,price_htg,stock,image}=req.body||{};
  if(!name||!category||!Number.isInteger(Number(price_htg))) return res.status(400).json({error:"Produit invalide"});
  const {rows}=await pool.query(`INSERT INTO products(name,category,price_htg,stock,image)
    VALUES($1,$2,$3,$4,$5) RETURNING id`,[name,category,Number(price_htg),Number(stock||0),image||null]);
  res.status(201).json(rows[0]);
});
app.patch("/api/admin/products/:id",auth,async(req,res)=>{
  const {name,category,price_htg,stock,image,active}=req.body||{};
  const {rowCount}=await pool.query(`UPDATE products SET
    name=COALESCE($1,name),category=COALESCE($2,category),price_htg=COALESCE($3,price_htg),
    stock=COALESCE($4,stock),image=COALESCE($5,image),active=COALESCE($6,active) WHERE id=$7`,
    [name,category,price_htg,stock,image,active,req.params.id]);
  res.json({updated:rowCount});
});
app.patch("/api/admin/orders/:id",auth,async(req,res)=>{
  const {payment_status,order_status,payment_reference}=req.body||{};
  const {rowCount}=await pool.query(`UPDATE orders SET
    payment_status=COALESCE($1,payment_status),order_status=COALESCE($2,order_status),
    payment_reference=COALESCE($3,payment_reference) WHERE id=$4`,
    [payment_status,order_status,payment_reference,req.params.id]);
  res.json({updated:rowCount});
});

app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"..","public","index.html")));

init().then(()=>app.listen(PORT,()=>console.log("Jismay-Love Store running on "+PORT)))
.catch(e=>{console.error(e);process.exit(1)});
