# Jismay-Love Store — $0 test deployment

## Services
- Render Free Web Service: $0, but Render warns Free services are not for production and can spin down after 15 minutes.
- Supabase Free: PostgreSQL database at $0, subject to free-tier quotas and pausing after inactivity.

## Steps
1. Create a free GitHub account and upload this project.
2. Create a Supabase Free project and copy its Postgres connection string.
3. In Supabase SQL Editor, run `server/schema.sql`.
4. On your computer/online Node environment, run:
   `npm install`
   `node server/create-admin-hash.js "YOUR_PRIVATE_PASSWORD"`
5. Put the resulting hash and a long random JWT secret in Render Environment Variables.
6. Create a Render Web Service from the GitHub repository:
   Build command: `npm install`
   Start command: `npm start`
   Plan: Free
7. Set `DATABASE_URL`, `JWT_SECRET`, `ADMIN_LOGIN=mario`, `ADMIN_PASSWORD_HASH`, `NATCASH_NUMBER=+50942585884`.
8. Run the seed script once with the Supabase connection string: `node server/seed.js`.
9. Render will provide a free `onrender.com` address.

## Important
This is a $0 testing/starting setup, not a guaranteed 24/7 production setup. Render explicitly says Free web services are not for production and can sleep after 15 minutes; Supabase Free projects can pause after 1 week of inactivity. A paid plan will be needed when the store requires reliable continuous operation.

Never send the admin password to me or put it in GitHub.
